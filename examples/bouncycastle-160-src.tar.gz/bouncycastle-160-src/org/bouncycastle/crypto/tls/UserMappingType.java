package org.bouncycastle.crypto.tls;

/**
 * RFC 4681
 */
public class UserMappingType
{
    /*
     * RFC 4681
     */
    public static final short upn_domain_hint = 64;
}
