package EDAN045F;

import java.util.*;

public class Test1 {

	public static void main(String ... args) {
		System.out.println("Hello, World!");
		Properties prop = new Properties();
		prop.save(null, "deprecated call");
	}
}
