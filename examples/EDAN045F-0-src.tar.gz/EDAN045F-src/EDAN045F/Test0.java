package EDAN045F;

public class Test0 {

	public static int []
	alpha(int[] array) {
		int x = 0;
		int v = 0;
		while (v < 100) {
			v += array[x++];
		}
		array[x] = 0;
		return array;
	}

	public static int []
	beta(int[] array) {
		int x = 0;
		int v = 0;
		while (v < 100) {
			v += array[x++];
		}
		if (x > 3) {
			x = -2 * v;
		}
		array[x * 0] = 0;
		return array;
	}

	public static int []
	gamma(int[] array) {
		int x = 0;
		int v = 0;
		int k = 1;
		while (v < 100) {
			v += array[x++];
			if ((v & 1) == 1) {
				k = -1;
			}
		}
		x = k * v;
		array[x] = 0;
		return array;
	}

	public static int[]
	delta(int t) {
		int[] d = new int[t];
		for (int i = 0; i < t; ++i) {
			d[i] = (i < 2)? 1 : d[i-1] + d[i-2];
			int unused = d[0];
		}
		return d;
	}

	public static int
	epsilon(int k) {
		if (k > 0) {
			k = 1;
		} else {
			k = 0;
		}
		return k;
	}

	static int sumup(int[] arg) {
		int offset = 1;
		int acc = arg[offset--];
		acc += arg[offset--];
		acc += arg[offset--];
		return acc;
	}

	static int sign(int v) {
		int result = 0;
		if (v > 0) {
			result = 1;
		} else if (v < 0) {
			result = -1;
		}
		return result;
	}
}
